package egovframework.msa.sample.service;

public interface CustomerApiService {
	String getCustomerDetail(String customerId);
}

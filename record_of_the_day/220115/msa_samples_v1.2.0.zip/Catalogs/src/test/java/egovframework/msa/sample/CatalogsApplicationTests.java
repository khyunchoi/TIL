package egovframework.msa.sample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CatalogsApplicationTests {

	@Test
	void contextLoads() {
	}

}

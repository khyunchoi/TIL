package ktds;
/*
 *################### 실기 평가 구현 가이드 ########################
 *
 * Book.class 구현 : TestMain.class 가 정상적으로 작동하도록 메서드 구현
 * 주의) 주어진 멤버변수와 메서드 외에 메서드나 멤버변수 추가 절대 금지
 * 
 * ############################################################
 */	
public class Book {
	//도서 제목
	private String name;
	//도서 가격
	private String price;
	//도서 수량
	private String amount;	
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public Book(String name, int price, int amount) {
		// TODO 04: 4번(도서 객체 생성 기능)
		this.name = name;
		this.price = Integer.toString(price);
		this.amount = Integer.toString(amount);
	}

	public String getBookInfo() {
		// TODO 07: 7번(도서 정보 조회 기능)
		return "도서명 : " + name +", 재고는 " + amount + "권 입니다.";
	}

}

package ktds;

import java.util.ArrayList;
/*
 *#################### 실기 평가 구현 가이드 ############################
 *
 * BookStroe.class 구현 : TestMain.class 가 정상적으로 작동하도록 메서드 구현
 * 주의) 주어진 멤버변수와 메서드 외에 메서드나 멤버변수 추가 절대 금지
 * 
 * #################################################################
 */	
public class BookStore {
	
	ArrayList<Book> books;
	
	public BookStore(String name) {
		// TODO 01: 1번(스토어 객체 생성과 출력기능)
		ArrayList<Book> books = new ArrayList<Book>();
		this.books = books;
		
		System.out.println("Ktds Store 가 생성되었습니다.");
	}

	public ArrayList<Book> getAllBooks() {
		// TODO 02: 2번(전체도서조회 기능)
		return books;
	}
	
	public String getMaxStockPriceBookTitle() {
		// TODO 03: 3번(도서별 총 재고가격이 가장 큰 도서 검색 기능)
		// 참고: (도서별 총 재고 가격 : 도서가격 * 권수)
		int maxStockPriceBook = 0;
		String title = "";
		for(Book book : books) {
			int stockPriceBook = Integer.parseInt(book.getPrice()) * Integer.parseInt(book.getAmount());
			if (maxStockPriceBook < stockPriceBook) {
				maxStockPriceBook = stockPriceBook;
				title = book.getName();
			}
		}
		return title;
	}	

	public void addBook(Book book) {
		// TODO 05: 5번(도서 객체 추가 기능)
		books.add(book);
		System.out.println("도서명 : " + book.getName() + ", 도서가 " + book.getAmount() + "권 입고되었습니다.");
	}

	public Book findBookByTitle(String title) {
		// TODO 06: 6번(도서 검색 기능)
		for(Book book : books) {
			if (book.getName().equals(title)) {
				return book;
			}
		}
		return null;
	}

	public void updateBookCountByTitle(String title, int count) {
		// TODO 08: 8번(도서 정보 갱신 기능)
		for(Book book : books) {
			if (book.getName().equals(title)) {
				book.setAmount(Integer.toString(count));
				System.out.println("도서정보갱신 ->> 도서명 : " + book.getName() + ", 재고 " + book.getAmount() + "권 입니다.");
				break;
			}
		}
		
	}

	public int getTotalBookCount() {
		// TODO 09: 9번(전체 도서 권수 조회 기능)
		int bookCount = 0;
		for(Book book : books) {
			bookCount += Integer.parseInt(book.getAmount());
		}
		
		return bookCount;
	}

	public void deleteBookByTitle(String title) {
		// TODO 10: 10번(도서 삭제 기능)
		int bookIndex = 0;
		for(Book book : books) {
			if (book.getName().equals(title)) {
				bookIndex = books.indexOf(book);
				System.out.println("도서 삭제 : " + book.getName() + " 삭제됨");
			}
		}
		books.remove(bookIndex);
		
	}	
}
